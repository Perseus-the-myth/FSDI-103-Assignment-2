
let product=prompt("Enter the product: ");
let quantity=prompt("Enter the quantity: ");
let price=prompt("Enter the price: ");
let perc=(0.08);
let towel=(25);
let bucket=(15);
let final=(price*quantity*perc+price*quantity);
console.log(product, quantity*price, 0.08*quantity*price, final);

